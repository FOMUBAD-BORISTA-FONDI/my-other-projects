import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

const SavedScreen = () => {
  return (
    <View
      style={{
        flex: 1,
        backgroundColor: "#e7e7e7",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <Text>Saved Screen</Text>
    </View>
  );
};

export default SavedScreen;