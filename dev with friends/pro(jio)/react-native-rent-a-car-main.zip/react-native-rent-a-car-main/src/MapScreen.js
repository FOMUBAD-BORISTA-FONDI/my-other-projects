import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

const MapScreen = () => {
  return (
    <View
      style={{
        flex: 1,
        backgroundColor: "#e7e7e7",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <Text>Map Screen</Text>
    </View>
  );
};

export default MapScreen;